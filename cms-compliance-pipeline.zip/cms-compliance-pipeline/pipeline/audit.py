"""
Immutable run audit log and data lineage.

Every pipeline execution writes an append-only JSONL record capturing what was
pulled, from where, when, how many rows, the payload hash, and every validation
result. This is the artifact an auditor asks for: it answers "where did this
number come from and has it changed" without re-running anything.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import sys
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_records(records: list[dict]) -> str:
    """Content hash of an extracted payload, stable across key ordering."""
    canonical = json.dumps(records, sort_keys=True, separators=(",", ":"), default=str)
    return sha256_bytes(canonical.encode("utf-8"))


@dataclass
class ExtractRecord:
    """Lineage for a single dataset pull."""

    dataset_key: str
    dataset_id: str
    title: str
    distribution_id: str | None
    source_url: str
    cms_modified: str | None
    cms_released: str | None
    cms_next_update: str | None
    row_count: int
    column_count: int
    content_sha256: str
    extracted_at: str
    duration_seconds: float
    status: str = "ok"
    error: str | None = None


@dataclass
class ValidationResult:
    dataset_key: str
    check: str
    severity: str          # fail | warn | info
    passed: bool
    detail: str
    observed: Any = None
    threshold: Any = None


@dataclass
class RunManifest:
    """The top-level audit object for one pipeline execution."""

    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    started_at: str = field(default_factory=utcnow)
    finished_at: str | None = None
    git_sha: str | None = None
    host: str = field(default_factory=socket.gethostname)
    python_version: str = field(default_factory=lambda: sys.version.split()[0])
    platform: str = field(default_factory=platform.platform)
    extracts: list[ExtractRecord] = field(default_factory=list)
    validations: list[ValidationResult] = field(default_factory=list)
    phi_attestation: str = (
        "All sources are CMS public-use files. No PHI, no beneficiary-level "
        "records, and no direct identifiers are ingested, stored, or emitted."
    )

    # -- accessors -------------------------------------------------------
    @property
    def failures(self) -> list[ValidationResult]:
        return [v for v in self.validations if v.severity == "fail" and not v.passed]

    @property
    def warnings(self) -> list[ValidationResult]:
        return [v for v in self.validations if v.severity == "warn" and not v.passed]

    @property
    def total_rows(self) -> int:
        return sum(e.row_count for e in self.extracts)

    @property
    def pass_rate(self) -> float:
        if not self.validations:
            return 0.0
        return sum(v.passed for v in self.validations) / len(self.validations)

    def exit_code(self) -> int:
        """Non-zero if any blocking gate failed — this is what CI keys on."""
        return 1 if self.failures else 0

    # -- persistence -----------------------------------------------------
    def close(self) -> None:
        self.finished_at = utcnow()
        self.git_sha = os.environ.get("GITHUB_SHA") or self.git_sha

    def write(self, audit_dir: Path) -> Path:
        audit_dir.mkdir(parents=True, exist_ok=True)
        payload = asdict(self)

        # Append-only ledger: one line per run, never rewritten.
        with (audit_dir / "runs.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, default=str) + "\n")

        # Full manifest for this run, addressable by run_id.
        path = audit_dir / f"manifest_{self.run_id}.json"
        path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

        # Convenience pointer for the reporting layer.
        (audit_dir / "latest.json").write_text(
            json.dumps(payload, indent=2, default=str), encoding="utf-8"
        )
        return path


def load_previous_run(audit_dir: Path) -> dict | None:
    """Second-to-last run, used for drift comparison."""
    ledger = audit_dir / "runs.jsonl"
    if not ledger.exists():
        return None
    lines = [ln for ln in ledger.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if len(lines) < 2:
        return None
    return json.loads(lines[-2])
