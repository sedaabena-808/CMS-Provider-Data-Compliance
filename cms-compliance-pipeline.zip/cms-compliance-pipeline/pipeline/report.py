"""
Report generation.

Renders the latest run manifest into a self-contained HTML control report.
The design goal is a document a reviewer can read top-to-bottom and a hiring
manager can skim in ten seconds: outcome first, exceptions second, lineage
last. No external assets beyond a webfont, so the file can be emailed or
committed to a repo and still render.
"""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from jinja2 import Template

TEMPLATE = Template(r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CMS Data Compliance Report — {{ run.run_id[:8] }}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,600;0,800&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet">
<style>
  :root{
    --ground:#eef1f2; --paper:#fff; --ink:#16232b; --muted:#5c6f78;
    --rule:#ccd6da; --rule-strong:#9aabb2;
    --pass:#1f6f5c; --advisory:#b07a16; --blocking:#9e2b25; --federal:#1b4965;
  }
  *{box-sizing:border-box}
  body{
    margin:0; background:var(--ground); color:var(--ink);
    font-family:"Public Sans",system-ui,sans-serif; font-size:15px; line-height:1.55;
    font-variant-numeric:tabular-nums;
  }
  .sheet{max-width:1080px;margin:0 auto;background:var(--paper);
         border-left:1px solid var(--rule);border-right:1px solid var(--rule);}
  .pad{padding:0 40px}
  @media(max-width:640px){.pad{padding:0 20px}}

  header{border-bottom:3px solid var(--ink);padding-top:40px;padding-bottom:22px}
  h1{font-family:"Source Serif 4",Georgia,serif;font-weight:600;
     font-size:clamp(28px,4.4vw,42px);line-height:1.08;margin:0 0 10px;
     letter-spacing:-.015em;max-width:20ch}
  .standfirst{font-size:16px;color:var(--muted);max-width:64ch;margin:0 0 20px}
  .runmeta{display:flex;flex-wrap:wrap;gap:8px 28px;font-size:12.5px;color:var(--muted)}
  .runmeta b{font-weight:600;color:var(--ink);font-weight:600}

  /* Hero: every executed control as one tick, read left to right. */
  .strip-block{padding-top:28px;padding-bottom:30px;border-bottom:1px solid var(--rule)}
  .strip{display:flex;gap:2px;height:58px;align-items:flex-end;margin:18px 0 12px}
  .tick{flex:1 1 0;min-width:2px;border-radius:1px 1px 0 0;
        transition:opacity .12s ease}
  .tick[data-o="pass"]{background:var(--pass);height:52%}
  .tick[data-o="advisory"]{background:var(--advisory);height:74%}
  .tick[data-o="blocking"]{background:var(--blocking);height:100%}
  .tick:hover{opacity:.62}
  .strip-caption{font-size:13px;color:var(--muted);max-width:70ch}
  .legend{display:flex;gap:20px;flex-wrap:wrap;font-size:12.5px;margin-top:14px}
  .legend span{display:flex;align-items:center;gap:7px}
  .swatch{width:11px;height:11px;border-radius:2px;display:inline-block}

  /* Verdict */
  .verdict{display:grid;grid-template-columns:200px 1fr;gap:36px;
           padding-top:30px;padding-bottom:30px;border-bottom:1px solid var(--rule)}
  @media(max-width:720px){.verdict{grid-template-columns:1fr;gap:20px}}
  .seal{border:2px solid var(--ink);padding:18px 12px 14px;text-align:center}
  .seal .g{font-family:"Source Serif 4",serif;font-size:66px;line-height:.9;
           font-weight:600;display:block}
  .seal .s{font-size:20px;font-weight:600;display:block;margin-top:6px}
  .seal .l{font-size:11.5px;color:var(--muted);margin-top:8px;display:block}
  .facts{display:grid;grid-template-columns:repeat(3,1fr);
         gap:1px;background:var(--rule);border:1px solid var(--rule)}
  @media(max-width:520px){.facts{grid-template-columns:repeat(2,1fr)}}
  .fact{background:var(--paper);padding:14px 16px}
  .fact .n{font-size:26px;font-weight:800;line-height:1.1;letter-spacing:-.02em}
  .fact .k{font-size:12.5px;color:var(--muted);margin-top:2px}
  .fact.bad .n{color:var(--blocking)}
  .fact.warn .n{color:var(--advisory)}

  h2{font-family:"Source Serif 4",serif;font-size:22px;font-weight:600;
     margin:34px 0 4px;letter-spacing:-.01em}
  .subhead{font-size:13.5px;color:var(--muted);margin:0 0 16px;max-width:70ch}

  table{width:100%;border-collapse:collapse;font-size:13.5px}
  th{text-align:left;font-weight:600;font-size:12.5px;color:var(--muted);
     padding:0 10px 8px;border-bottom:1.5px solid var(--rule-strong);white-space:nowrap}
  td{padding:11px 10px;border-bottom:1px solid var(--rule);vertical-align:top}
  tbody tr td:first-child{border-left:4px solid transparent;padding-left:12px}
  tr[data-sev="blocking"] td:first-child{border-left-color:var(--blocking)}
  tr[data-sev="advisory"] td:first-child{border-left-color:var(--advisory)}
  tr[data-sev="pass"] td:first-child{border-left-color:var(--pass)}
  .num{text-align:right}
  .grade{font-weight:800}
  .grade.A,.grade.B{color:var(--pass)} .grade.C{color:var(--advisory)}
  .grade.D,.grade.F{color:var(--blocking)}
  .dim{color:var(--muted)}
  .hash{font-size:11.5px;color:var(--muted);word-break:break-all}
  .pill{display:inline-block;padding:1px 8px;border:1px solid var(--rule-strong);
        border-radius:10px;font-size:11.5px;color:var(--muted)}

  .exception{border-top:1px solid var(--rule);padding:14px 0 14px 14px;
             border-left:4px solid var(--advisory)}
  .exception.blocking{border-left-color:var(--blocking)}
  .exception .c{font-weight:600;font-size:14px}
  .exception .d{font-size:13.5px;color:var(--muted);margin-top:2px}
  .clean{border:1px solid var(--rule);border-left:4px solid var(--pass);
         padding:16px 18px;font-size:14px}

  .attest{background:#f7f9f9;border:1px solid var(--rule);padding:18px 20px;
          font-size:13.5px;margin:20px 0 0;max-width:74ch}
  footer{padding-top:26px;padding-bottom:46px;margin-top:34px;
         border-top:3px solid var(--ink);font-size:12.5px;color:var(--muted)}
  @media print{
    body{background:#fff} .sheet{border:0;max-width:none}
    .tick:hover{opacity:1} h2{break-after:avoid} tr{break-inside:avoid}
  }
  @media(prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="sheet">

  <header class="pad">
    <h1>CMS provider data compliance report</h1>
    <p class="standfirst">Automated extraction, control testing, and lineage capture across
      {{ scorecard.portfolio.datasets }} public-use CMS datasets. Every figure below is
      reproducible from the run manifest committed alongside this report.</p>
    <div class="runmeta">
      <span>Run <b>{{ run.run_id[:8] }}</b></span>
      <span>Executed <b>{{ started }}</b></span>
      <span>Duration <b>{{ duration }}</b></span>
      <span>Source <b>CMS Provider Data Catalog</b></span>
    </div>
  </header>

  <section class="strip-block pad">
    <h2 style="margin-top:0">Control execution</h2>
    <p class="subhead">Each tick is one control test. Height and colour encode outcome, so a
      single glance shows whether exceptions are isolated or systemic.</p>
    <div class="strip" role="img"
         aria-label="{{ ticks|length }} control tests: {{ counts.pass }} passed, {{ counts.advisory }} advisory exceptions, {{ counts.blocking }} blocking failures">
      {% for t in ticks %}<div class="tick" data-o="{{ t.outcome }}" title="{{ t.dataset }} — {{ t.check }}: {{ t.detail }}"></div>{% endfor %}
    </div>
    <p class="strip-caption">{{ counts.total }} controls executed across
      {{ scorecard.portfolio.datasets }} datasets and {{ "{:,}".format(scorecard.portfolio.total_rows) }} ingested rows.</p>
    <div class="legend">
      <span><i class="swatch" style="background:var(--pass)"></i>Passed ({{ counts.pass }})</span>
      <span><i class="swatch" style="background:var(--advisory)"></i>Advisory exception ({{ counts.advisory }})</span>
      <span><i class="swatch" style="background:var(--blocking)"></i>Blocking failure ({{ counts.blocking }})</span>
    </div>
  </section>

  <section class="verdict pad">
    <div class="seal">
      <span class="g">{{ scorecard.portfolio.grade }}</span>
      <span class="s">{{ scorecard.portfolio.score }}</span>
      <span class="l">Criticality-weighted<br>portfolio score</span>
    </div>
    <div class="facts">
      <div class="fact"><div class="n">{{ scorecard.portfolio.datasets }}</div><div class="k">Datasets tracked</div></div>
      <div class="fact"><div class="n">{{ "{:,}".format(scorecard.portfolio.total_rows) }}</div><div class="k">Rows ingested</div></div>
      <div class="fact"><div class="n">{{ counts.total }}</div><div class="k">Controls executed</div></div>
      <div class="fact {% if counts.blocking %}bad{% endif %}"><div class="n">{{ counts.blocking }}</div><div class="k">Blocking failures</div></div>
      <div class="fact {% if counts.advisory %}warn{% endif %}"><div class="n">{{ counts.advisory }}</div><div class="k">Advisory exceptions</div></div>
      <div class="fact"><div class="n">{{ pass_rate }}%</div><div class="k">Control pass rate</div></div>
    </div>
  </section>

  <section class="pad">
    <h2>Dataset register</h2>
    <p class="subhead">One row per governed data product, graded independently. Freshness is
      measured against the cadence CMS publishes for that file, not against the run date.</p>
    <table>
      <thead><tr>
        <th>Dataset</th><th>Domain</th><th>Criticality</th>
        <th class="num">Rows</th><th class="num">Cols</th>
        <th class="num">Age</th><th class="num">Exceptions</th><th class="num">Score</th><th>Grade</th>
      </tr></thead>
      <tbody>
      {% for d in scorecard.datasets %}
        <tr data-sev="{{ 'blocking' if d.blocking_failures else ('advisory' if d.advisory_failures else 'pass') }}">
          <td><strong>{{ d.title }}</strong><br><span class="dim">{{ d.dataset_key }}</span></td>
          <td><span class="pill">{{ d.domain }}</span></td>
          <td>{{ d.criticality }}</td>
          <td class="num">{{ "{:,}".format(d.rows) }}</td>
          <td class="num">{{ d.columns }}</td>
          <td class="num">{{ d.freshness_days if d.freshness_days is not none else '—' }}{% if d.freshness_days is not none %}d{% endif %}</td>
          <td class="num">{{ d.blocking_failures + d.advisory_failures }} / {{ d.checks_run }}</td>
          <td class="num">{{ d.score }}</td>
          <td class="grade {{ d.grade }}">{{ d.grade }}</td>
        </tr>
      {% endfor %}
      </tbody>
    </table>
  </section>

  <section class="pad">
    <h2>Exceptions</h2>
    <p class="subhead">Only failed controls appear here. Advisory items are logged and tracked;
      blocking items stop the affected dataset from being promoted to the warehouse.</p>
    {% if exceptions %}
      {% for dataset, items in exceptions.items() %}
        <h3 style="font-size:15px;margin:24px 0 0">{{ dataset }}</h3>
        {% for e in items %}
          <div class="exception {{ 'blocking' if e.severity == 'fail' else '' }}">
            <div class="c">{{ e.check }}</div>
            <div class="d">{{ e.detail }}{% if e.threshold is not none %} · threshold {{ e.threshold }}{% endif %}</div>
          </div>
        {% endfor %}
      {% endfor %}
    {% else %}
      <div class="clean">No control exceptions. Every dataset passed schema, key, freshness,
        volume, null-rate, type, and identifier screening.</div>
    {% endif %}
  </section>

  <section class="pad">
    <h2>Lineage and reproducibility</h2>
    <p class="subhead">Content hashes are taken over the extracted payload before transformation.
      An unchanged hash across runs proves the upstream file did not move.</p>
    <table>
      <thead><tr><th>Dataset</th><th>CMS modified</th><th>Next update</th>
        <th class="num">Pull time</th><th>Payload SHA-256</th></tr></thead>
      <tbody>
      {% for e in run.extracts %}
        <tr data-sev="pass">
          <td>{{ e.dataset_key }}<br><span class="dim">{{ e.dataset_id }}</span></td>
          <td>{{ e.cms_modified or '—' }}</td>
          <td>{{ e.cms_next_update or '—' }}</td>
          <td class="num">{{ e.duration_seconds }}s</td>
          <td class="hash">{{ e.content_sha256[:32] }}…</td>
        </tr>
      {% endfor %}
      </tbody>
    </table>

    <p class="attest"><strong>Data handling attestation.</strong> {{ run.phi_attestation }}
      Control PHI-01 screens every ingested schema for direct-identifier column patterns and
      blocks promotion on any match.</p>
  </section>

  <footer class="pad">
    Generated {{ generated }} · Python {{ run.python_version }} · run {{ run.run_id }}<br>
    Source data: Centers for Medicare &amp; Medicaid Services Provider Data Catalog, public use files.
  </footer>

</div>
</body>
</html>""")


def _duration(run: dict) -> str:
    try:
        a = datetime.fromisoformat(run["started_at"])
        b = datetime.fromisoformat(run["finished_at"])
        secs = int((b - a).total_seconds())
        return f"{secs // 60}m {secs % 60}s" if secs >= 60 else f"{secs}s"
    except Exception:  # noqa: BLE001
        return "—"


def render(audit_dir: Path, out_dir: Path) -> Path:
    audit_dir, out_dir = Path(audit_dir), Path(out_dir)
    run = json.loads((audit_dir / "latest.json").read_text(encoding="utf-8"))
    scorecard = json.loads((audit_dir / "scorecard.json").read_text(encoding="utf-8"))

    ticks, counts = [], {"pass": 0, "advisory": 0, "blocking": 0}
    exceptions: dict[str, list[dict]] = defaultdict(list)

    for v in run["validations"]:
        if v["passed"]:
            outcome = "pass"
        else:
            outcome = "blocking" if v["severity"] == "fail" else "advisory"
            exceptions[v["dataset_key"]].append(v)
        counts[outcome] += 1
        ticks.append({
            "outcome": outcome,
            "dataset": v["dataset_key"],
            "check": v["check"],
            "detail": v["detail"],
        })

    counts["total"] = len(ticks)
    pass_rate = round(counts["pass"] / counts["total"] * 100, 1) if counts["total"] else 0.0

    html = TEMPLATE.render(
        run=run,
        scorecard=scorecard,
        ticks=ticks,
        counts=counts,
        pass_rate=pass_rate,
        exceptions=dict(exceptions),
        started=run["started_at"].replace("T", " ").replace("+00:00", " UTC"),
        duration=_duration(run),
        generated=datetime.now().strftime("%Y-%m-%d %H:%M"),
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "compliance_report.html"
    path.write_text(html, encoding="utf-8")
    return path
