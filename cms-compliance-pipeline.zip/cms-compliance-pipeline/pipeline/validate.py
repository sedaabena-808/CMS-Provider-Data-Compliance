"""
Validation gate engine.

Each check is a named, severity-tagged control with an observed value and a
threshold — the same shape a control-testing workpaper takes. Blocking checks
(`fail`) stop promotion to the warehouse and return a non-zero exit code;
advisory checks (`warn`) are logged and surfaced on the scorecard but do not
halt the run.

Controls implemented
--------------------
SCHEMA-01  required columns present
KEY-01     primary key columns present
KEY-02     primary key unique
FRESH-01   upstream publication within expected cadence
FRESH-02   CMS next-update date not in the past
VOL-01     row count within drift tolerance of prior run
NULL-01    null rate on required columns under threshold
TYPE-01    numeric-looking measure columns parse cleanly
PHI-01     no direct-identifier columns present in a public-use extract
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Iterable

import pandas as pd

from .audit import ExtractRecord, ValidationResult

# Column-name patterns that must never appear in a public-use ingest.
PHI_PATTERNS = [
    r"\bssn\b", r"social_security", r"\bmbi\b", r"beneficiary_id",
    r"\bhicn\b", r"date_of_birth", r"\bdob\b", r"patient_name",
    r"member_id", r"\bmrn\b",
]


def _parse_date(value: str | None) -> date | None:
    if not value:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%m/%d/%Y"):
        try:
            return datetime.strptime(str(value)[:19], fmt).date()
        except ValueError:
            continue
    return None


class Validator:
    def __init__(self, rules: dict):
        self.drift_pct = float(rules.get("row_count_drift_pct", 20))
        self.null_threshold = float(rules.get("null_rate_threshold", 0.6))

    # -- individual controls --------------------------------------------

    def _schema(self, key: str, df: pd.DataFrame, required: Iterable[str]) -> ValidationResult:
        missing = [c for c in required if c not in df.columns]
        return ValidationResult(
            dataset_key=key,
            check="SCHEMA-01 required_columns_present",
            severity="fail",
            passed=not missing,
            detail="all required columns present" if not missing
                   else f"missing columns: {', '.join(missing)}",
            observed=len(df.columns),
            threshold=list(required),
        )

    def _key_present(self, key: str, df: pd.DataFrame, pk: list[str]) -> ValidationResult:
        missing = [c for c in pk if c not in df.columns]
        return ValidationResult(
            dataset_key=key,
            check="KEY-01 primary_key_present",
            severity="fail",
            passed=not missing,
            detail="primary key resolvable" if not missing
                   else f"primary key column(s) absent: {', '.join(missing)}",
            observed=pk,
        )

    def _key_unique(self, key: str, df: pd.DataFrame, pk: list[str]) -> ValidationResult:
        if df.empty or any(c not in df.columns for c in pk):
            return ValidationResult(key, "KEY-02 primary_key_unique", "warn", True,
                                    "skipped — key not evaluable")
        dupes = int(df.duplicated(subset=pk).sum())
        pct = round(dupes / len(df) * 100, 2) if len(df) else 0.0
        return ValidationResult(
            dataset_key=key,
            check="KEY-02 primary_key_unique",
            severity="warn",
            passed=dupes == 0,
            detail=f"{dupes:,} duplicate key rows ({pct}%)" if dupes
                   else "primary key is unique",
            observed=dupes,
            threshold=0,
        )

    def _freshness(self, key: str, rec: ExtractRecord, cadence_days: int) -> list[ValidationResult]:
        out: list[ValidationResult] = []
        modified = _parse_date(rec.cms_modified)
        today = date.today()

        if modified:
            age = (today - modified).days
            out.append(ValidationResult(
                dataset_key=key,
                check="FRESH-01 upstream_within_cadence",
                severity="warn",
                passed=age <= cadence_days,
                detail=f"CMS last modified {modified} ({age}d ago); expected within {cadence_days}d",
                observed=age,
                threshold=cadence_days,
            ))

        nxt = _parse_date(rec.cms_next_update)
        if nxt:
            overdue = (today - nxt).days
            out.append(ValidationResult(
                dataset_key=key,
                check="FRESH-02 next_update_not_overdue",
                severity="warn",
                passed=overdue <= 0,
                detail=f"CMS scheduled next update {nxt}"
                       + (f" — overdue by {overdue}d" if overdue > 0 else " — on schedule"),
                observed=str(nxt),
            ))
        return out

    def _volume(self, key: str, rec: ExtractRecord, prior_rows: int | None) -> ValidationResult:
        if not prior_rows:
            return ValidationResult(key, "VOL-01 row_count_drift", "warn", True,
                                    f"baseline established at {rec.row_count:,} rows",
                                    observed=rec.row_count)
        drift = abs(rec.row_count - prior_rows) / prior_rows * 100
        return ValidationResult(
            dataset_key=key,
            check="VOL-01 row_count_drift",
            severity="warn",
            passed=drift <= self.drift_pct,
            detail=f"{prior_rows:,} -> {rec.row_count:,} rows ({drift:.1f}% change)",
            observed=round(drift, 2),
            threshold=self.drift_pct,
        )

    def _nulls(self, key: str, df: pd.DataFrame, required: Iterable[str]) -> list[ValidationResult]:
        out: list[ValidationResult] = []
        if df.empty:
            return out
        for col in required:
            if col not in df.columns:
                continue
            series = df[col].astype("string").str.strip()
            rate = float(((series.isna()) | (series == "")).mean())
            out.append(ValidationResult(
                dataset_key=key,
                check=f"NULL-01 null_rate[{col}]",
                severity="warn",
                passed=rate <= self.null_threshold,
                detail=f"{col}: {rate:.1%} null/blank",
                observed=round(rate, 4),
                threshold=self.null_threshold,
            ))
        return out

    def _phi(self, key: str, df: pd.DataFrame) -> ValidationResult:
        hits = [c for c in df.columns
                if any(re.search(p, c.lower()) for p in PHI_PATTERNS)]
        return ValidationResult(
            dataset_key=key,
            check="PHI-01 no_direct_identifiers",
            severity="fail",
            passed=not hits,
            detail="no direct-identifier columns detected" if not hits
                   else f"POSSIBLE IDENTIFIER COLUMNS: {', '.join(hits)}",
            observed=hits or None,
        )

    def _numeric(self, key: str, df: pd.DataFrame, enabled: bool = True) -> ValidationResult:
        """CMS encodes suppression as text ('Not Available'); confirm the
        numeric signal survives coercion rather than collapsing to all-null."""
        if not enabled:
            return ValidationResult(key, "TYPE-01 numeric_parse", "info", True,
                                    "measure is categorical by design; numeric parse not applicable")
        target = next((c for c in ("score", "measure_score", "rate") if c in df.columns), None)
        if target is None or df.empty:
            return ValidationResult(key, "TYPE-01 numeric_parse", "info", True,
                                    "no numeric measure column on this dataset")
        coerced = pd.to_numeric(df[target], errors="coerce")
        usable = float(coerced.notna().mean())
        return ValidationResult(
            dataset_key=key,
            check=f"TYPE-01 numeric_parse[{target}]",
            severity="warn",
            passed=usable > 0.10,
            detail=f"{usable:.1%} of {target} values parse as numeric "
                   f"(remainder are CMS suppression/footnote codes)",
            observed=round(usable, 4),
            threshold=0.10,
        )

    # -- orchestration ---------------------------------------------------

    def run(
        self,
        spec: dict,
        df: pd.DataFrame,
        rec: ExtractRecord,
        prior_rows: int | None = None,
    ) -> list[ValidationResult]:
        key = spec["key"]
        required = spec.get("required_columns", [])
        pk = spec.get("primary_key", [])
        cadence = int(spec.get("expected_cadence_days", 180))

        results = [
            self._schema(key, df, required),
            self._key_present(key, df, pk),
            self._key_unique(key, df, pk),
            self._phi(key, df),
            self._numeric(key, df, spec.get("numeric_measure", True)),
            self._volume(key, rec, prior_rows),
        ]
        results.extend(self._freshness(key, rec, cadence))
        results.extend(self._nulls(key, df, required))

        # Low-criticality datasets never block the pipeline.
        if spec.get("criticality") == "low":
            for r in results:
                if r.severity == "fail":
                    r.severity = "warn"
        return results
