"""
Extraction layer.

Pulls CMS datastore records with cursor pagination, exponential backoff, and
content hashing. Every pull is written to a date-partitioned Parquet snapshot
so any prior state of the warehouse can be reconstructed and diffed — the
reproducibility property that makes the pipeline auditable.
"""

from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

import pandas as pd
import requests

from .audit import ExtractRecord, sha256_records, utcnow
from .catalog import CatalogEntry, USER_AGENT

DATASTORE = "https://data.cms.gov/provider-data/api/1/datastore/query"
MAX_PAGE_SIZE = 1000  # enforced server-side by the CMS datastore


class Extractor:
    def __init__(
        self,
        raw_dir: Path,
        page_size: int = 2000,
        max_retries: int = 5,
        timeout: int = 120,
        max_workers: int = 6,
    ):
        self.raw_dir = Path(raw_dir)
        self.page_size = min(page_size, MAX_PAGE_SIZE)
        self.max_retries = max_retries
        self.timeout = timeout
        self.max_workers = max_workers
        self._local = threading.local()

    @property
    def session(self) -> requests.Session:
        """One session per worker thread; requests.Session is not thread-safe."""
        if not hasattr(self._local, "session"):
            s = requests.Session()
            s.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
            self._local.session = s
        return self._local.session

    def _page(self, dist_id: str, offset: int, limit: int) -> dict:
        url = f"{DATASTORE}/{dist_id}"
        params = {
            "limit": limit,
            "offset": offset,
            "count": "true",
            "results": "true",
            "schema": "false",
        }
        last: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                resp = self.session.get(url, params=params, timeout=self.timeout)
                if resp.status_code in (429, 500, 502, 503, 504):
                    raise requests.HTTPError(f"retryable status {resp.status_code}")
                if 400 <= resp.status_code < 500:
                    # Client error: retrying cannot help. Surface it immediately.
                    raise RuntimeError(
                        f"HTTP {resp.status_code} from CMS datastore: {resp.text[:200]}"
                    )
                resp.raise_for_status()
                return resp.json()
            except RuntimeError:
                raise
            except Exception as exc:  # noqa: BLE001 - retried
                last = exc
                time.sleep(min(2**attempt, 30))
        raise RuntimeError(f"page fetch failed offset={offset} dist={dist_id}") from last

    def _fetch_all_pages(self, dist_id: str, row_limit: int | None) -> list[dict]:
        """Page 0 reports the total; the remainder are pulled concurrently."""
        first = self._page(dist_id, 0, self.page_size)
        records = list(first.get("results") or [])
        total = first.get("count")

        if total is None or len(records) < self.page_size:
            return records[:row_limit] if row_limit else records

        target = min(total, row_limit) if row_limit else total
        offsets = list(range(self.page_size, target, self.page_size))
        if not offsets:
            return records[:target]

        pages: dict[int, list[dict]] = {}
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {
                pool.submit(self._page, dist_id, off, self.page_size): off
                for off in offsets
            }
            for fut in as_completed(futures):
                pages[futures[fut]] = fut.result().get("results") or []

        # Reassemble in offset order so the payload hash stays deterministic.
        for off in offsets:
            records.extend(pages.get(off, []))

        return records[:target]

    def fetch(
        self,
        spec: dict,
        entry: CatalogEntry,
    ) -> tuple[pd.DataFrame, ExtractRecord]:
        """Pull one dataset in full (or to `row_limit`) and snapshot it."""
        started = time.time()
        key = spec["key"]

        records = self._fetch_all_pages(entry.distribution_id, spec.get("row_limit"))
        df = pd.DataFrame.from_records(records)

        # Provenance columns travel with the data into the warehouse.
        if not df.empty:
            df["_dataset_key"] = key
            df["_cms_modified"] = entry.modified
            df["_ingested_at"] = utcnow()

        record = ExtractRecord(
            dataset_key=key,
            dataset_id=spec["dataset_id"],
            title=entry.title,
            distribution_id=entry.distribution_id,
            source_url=f"{DATASTORE}/{entry.distribution_id}",
            cms_modified=entry.modified,
            cms_released=entry.released,
            cms_next_update=entry.next_update,
            row_count=len(df),
            column_count=len(df.columns),
            content_sha256=sha256_records(records),
            extracted_at=utcnow(),
            duration_seconds=round(time.time() - started, 2),
        )

        self._snapshot(key, df)
        return df, record

    def _snapshot(self, key: str, df: pd.DataFrame) -> Path | None:
        """Date-partitioned immutable copy of the raw pull."""
        if df.empty:
            return None
        part = self.raw_dir / f"dataset={key}" / f"ingest_date={date.today().isoformat()}"
        part.mkdir(parents=True, exist_ok=True)
        path = part / "data.parquet"
        df.to_parquet(path, index=False)
        return path
