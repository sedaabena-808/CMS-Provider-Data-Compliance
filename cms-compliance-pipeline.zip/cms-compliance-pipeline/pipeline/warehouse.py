"""
Transform + load.

Normalizes heterogeneous CMS files into a small conformed model and loads it
into DuckDB. CMS publishes each quality domain with its own column naming, so
the transform's job is to reconcile them onto a single facility/measure grain
that can be queried across domains.

Model
-----
raw_<key>            one table per source, verbatim + provenance columns
dim_facility         conformed provider dimension (hospital, SNF, HHA)
fact_quality_measure long-format measure results across all quality domains
vw_compliance_summary state x domain rollup
"""

from __future__ import annotations

import re
from pathlib import Path

import duckdb
import pandas as pd

# Source column -> conformed column, applied best-effort per dataset.
FACILITY_ID_CANDIDATES = [
    "facility_id", "cms_certification_number_ccn", "provider_id", "ccn", "npi",
]
FACILITY_NAME_CANDIDATES = [
    "facility_name", "provider_name", "organization_name", "hospital_name",
]
MEASURE_ID_CANDIDATES = ["measure_id", "hcahps_measure_id", "measure_code"]
MEASURE_NAME_CANDIDATES = ["measure_name", "hcahps_question", "measure_description"]
SCORE_CANDIDATES = ["score", "measure_score", "rate", "hcahps_answer_percent"]


def _first_present(df: pd.DataFrame, candidates: list[str]) -> str | None:
    return next((c for c in candidates if c in df.columns), None)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """snake_case, strip punctuation — CMS column casing is inconsistent."""
    df = df.copy()
    df.columns = [
        re.sub(r"_+", "_", re.sub(r"[^0-9a-zA-Z]+", "_", str(c)).strip("_")).lower()
        for c in df.columns
    ]
    return df


def to_facility_dim(df: pd.DataFrame, spec: dict) -> pd.DataFrame:
    """Extract the provider dimension from a facility-grain dataset."""
    fid = _first_present(df, FACILITY_ID_CANDIDATES)
    if fid is None:
        return pd.DataFrame()

    name = _first_present(df, FACILITY_NAME_CANDIDATES)
    out = pd.DataFrame({
        "facility_id": df[fid].astype("string").str.strip(),
        "facility_name": df[name].astype("string") if name else pd.NA,
        "provider_domain": spec["key"],
        "state": df["state"].astype("string") if "state" in df.columns else pd.NA,
        "city": (df["citytown"] if "citytown" in df.columns
                 else df["city_town"] if "city_town" in df.columns else pd.NA),
        "zip_code": df["zip_code"].astype("string") if "zip_code" in df.columns else pd.NA,
        "ownership": (df["hospital_ownership"] if "hospital_ownership" in df.columns
                      else df["ownership_type"] if "ownership_type" in df.columns else pd.NA),
        "facility_type": (df["hospital_type"] if "hospital_type" in df.columns else pd.NA),
        "overall_rating": (df["hospital_overall_rating"]
                           if "hospital_overall_rating" in df.columns
                           else df["overall_rating"] if "overall_rating" in df.columns
                           else pd.NA),
    })
    return out[out["facility_id"].notna() & (out["facility_id"] != "")]


def to_measure_fact(df: pd.DataFrame, spec: dict) -> pd.DataFrame:
    """Melt a facility-measure dataset onto the conformed long grain."""
    fid = _first_present(df, FACILITY_ID_CANDIDATES)
    mid = _first_present(df, MEASURE_ID_CANDIDATES)
    if fid is None or mid is None:
        return pd.DataFrame()

    mname = _first_present(df, MEASURE_NAME_CANDIDATES)
    score = _first_present(df, SCORE_CANDIDATES)

    out = pd.DataFrame({
        "facility_id": df[fid].astype("string").str.strip(),
        "measure_id": df[mid].astype("string").str.strip(),
        "measure_name": df[mname].astype("string") if mname else pd.NA,
        "domain": spec["domain"],
        "dataset_key": spec["key"],
        "score_raw": df[score].astype("string") if score else pd.NA,
        "state": df["state"].astype("string") if "state" in df.columns else pd.NA,
        "start_date": df["start_date"] if "start_date" in df.columns else pd.NA,
        "end_date": df["end_date"] if "end_date" in df.columns else pd.NA,
        "footnote": df["footnote"].astype("string") if "footnote" in df.columns else pd.NA,
    })

    out["score_numeric"] = pd.to_numeric(out["score_raw"], errors="coerce")
    # CMS suppresses small-cell values with text codes; preserve the reason.
    out["is_suppressed"] = out["score_numeric"].isna() & out["score_raw"].notna()
    return out[out["facility_id"].notna() & (out["facility_id"] != "")]


class Warehouse:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.con = duckdb.connect(str(self.db_path))

    def load_raw(self, key: str, df: pd.DataFrame) -> int:
        if df.empty:
            return 0
        table = f"raw_{key}"
        self.con.register("_incoming", df)
        self.con.execute(f'CREATE OR REPLACE TABLE "{table}" AS SELECT * FROM _incoming')
        self.con.unregister("_incoming")
        return len(df)

    def load_conformed(
        self,
        facilities: list[pd.DataFrame],
        measures: list[pd.DataFrame],
    ) -> dict[str, int]:
        counts = {"dim_facility": 0, "fact_quality_measure": 0}

        fac = [f for f in facilities if not f.empty]
        if fac:
            dim = pd.concat(fac, ignore_index=True)
            dim = dim.drop_duplicates(subset=["facility_id", "provider_domain"])
            self.con.register("_dim", dim)
            self.con.execute("CREATE OR REPLACE TABLE dim_facility AS SELECT * FROM _dim")
            self.con.unregister("_dim")
            counts["dim_facility"] = len(dim)

        mea = [m for m in measures if not m.empty]
        if mea:
            fact = pd.concat(mea, ignore_index=True)
            self.con.register("_fact", fact)
            self.con.execute(
                "CREATE OR REPLACE TABLE fact_quality_measure AS SELECT * FROM _fact"
            )
            self.con.unregister("_fact")
            counts["fact_quality_measure"] = len(fact)

        self._build_views()
        return counts

    def _build_views(self) -> None:
        tables = {r[0] for r in self.con.execute("SHOW TABLES").fetchall()}
        if not {"fact_quality_measure", "dim_facility"} <= tables:
            return
        self.con.execute("""
            CREATE OR REPLACE VIEW vw_compliance_summary AS
            SELECT
                f.state,
                f.domain,
                COUNT(DISTINCT f.facility_id)              AS facilities,
                COUNT(*)                                   AS measure_rows,
                SUM(CASE WHEN f.is_suppressed THEN 1 ELSE 0 END) AS suppressed_rows,
                ROUND(100.0 * SUM(CASE WHEN f.is_suppressed THEN 1 ELSE 0 END)
                      / NULLIF(COUNT(*), 0), 2)            AS suppression_pct,
                ROUND(AVG(f.score_numeric), 3)             AS avg_score
            FROM fact_quality_measure f
            WHERE f.state IS NOT NULL AND f.state <> ''
            GROUP BY 1, 2
            ORDER BY 1, 2
        """)
        self.con.execute("""
            CREATE OR REPLACE VIEW vw_measure_coverage AS
            SELECT
                domain,
                dataset_key,
                measure_id,
                ANY_VALUE(measure_name)                    AS measure_name,
                COUNT(DISTINCT facility_id)                AS reporting_facilities,
                ROUND(100.0 * SUM(CASE WHEN is_suppressed THEN 1 ELSE 0 END)
                      / NULLIF(COUNT(*), 0), 2)            AS suppression_pct
            FROM fact_quality_measure
            GROUP BY 1, 2, 3
            ORDER BY reporting_facilities DESC
        """)

    def query(self, sql: str) -> pd.DataFrame:
        return self.con.execute(sql).df()

    def table_sizes(self) -> dict[str, int]:
        out = {}
        for (name,) in self.con.execute("SHOW TABLES").fetchall():
            out[name] = self.con.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]
        return out

    def close(self) -> None:
        self.con.close()
