"""
Compliance scorecard.

Converts raw validation output into a graded, per-dataset assessment. The
scoring is deliberately transparent — a weighted deduction model rather than an
opaque index — because a compliance score nobody can reconstruct by hand is a
score nobody will trust in a review.

Deductions
----------
blocking control failed   -25 each
advisory control failed    -6 each
dataset failed to extract  score forced to 0
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

from .audit import RunManifest

GRADE_BANDS = [(90, "A"), (80, "B"), (70, "C"), (60, "D"), (0, "F")]


def grade(score: float) -> str:
    return next(g for threshold, g in GRADE_BANDS if score >= threshold)


@dataclass
class DatasetScore:
    dataset_key: str
    title: str
    domain: str
    criticality: str
    rows: int
    columns: int
    score: float
    grade: str
    blocking_failures: int
    advisory_failures: int
    checks_run: int
    cms_modified: str | None
    freshness_days: int | None
    status: str


def build(manifest: RunManifest, specs: dict[str, dict]) -> list[DatasetScore]:
    scores: list[DatasetScore] = []

    for rec in manifest.extracts:
        spec = specs.get(rec.dataset_key, {})
        checks = [v for v in manifest.validations if v.dataset_key == rec.dataset_key]
        blocking = [v for v in checks if v.severity == "fail" and not v.passed]
        advisory = [v for v in checks if v.severity == "warn" and not v.passed]

        if rec.status != "ok":
            value = 0.0
        else:
            value = max(0.0, 100.0 - 25 * len(blocking) - 6 * len(advisory))

        freshness = next(
            (v.observed for v in checks
             if v.check.startswith("FRESH-01") and isinstance(v.observed, int)),
            None,
        )

        scores.append(DatasetScore(
            dataset_key=rec.dataset_key,
            title=rec.title,
            domain=spec.get("domain", "unknown"),
            criticality=spec.get("criticality", "medium"),
            rows=rec.row_count,
            columns=rec.column_count,
            score=round(value, 1),
            grade=grade(value),
            blocking_failures=len(blocking),
            advisory_failures=len(advisory),
            checks_run=len(checks),
            cms_modified=rec.cms_modified,
            freshness_days=freshness,
            status=rec.status,
        ))

    return sorted(scores, key=lambda s: (s.score, -s.rows))


def portfolio_score(scores: list[DatasetScore]) -> dict:
    """Criticality-weighted rollup across the tracked portfolio."""
    if not scores:
        return {"score": 0.0, "grade": "F", "datasets": 0}

    weights = {"high": 3.0, "medium": 2.0, "low": 1.0}
    numerator = sum(s.score * weights.get(s.criticality, 2.0) for s in scores)
    denominator = sum(weights.get(s.criticality, 2.0) for s in scores)
    value = round(numerator / denominator, 1)

    return {
        "score": value,
        "grade": grade(value),
        "datasets": len(scores),
        "total_rows": sum(s.rows for s in scores),
        "blocking_failures": sum(s.blocking_failures for s in scores),
        "advisory_failures": sum(s.advisory_failures for s in scores),
        "checks_run": sum(s.checks_run for s in scores),
        "datasets_failed": sum(1 for s in scores if s.status != "ok"),
    }


def as_dicts(scores: list[DatasetScore]) -> list[dict]:
    return [asdict(s) for s in scores]
