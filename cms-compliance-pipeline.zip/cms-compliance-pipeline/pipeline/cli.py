"""
Pipeline orchestrator.

    python -m pipeline.cli run                  # full pipeline
    python -m pipeline.cli run --only hospital_general,hcahps
    python -m pipeline.cli catalog --search "nursing home"
    python -m pipeline.cli report                # rebuild HTML from last run

Exit code is 1 when any blocking control fails, so CI treats a data-quality
regression the same way it treats a broken build.
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

import yaml

from .audit import ExtractRecord, RunManifest, load_previous_run, utcnow
from .catalog import CatalogClient
from .extract import Extractor
from .scorecard import as_dicts, build, portfolio_score
from .validate import Validator
from .warehouse import Warehouse, normalize_columns, to_facility_dim, to_measure_fact

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config" / "datasets.yml"
DATA = ROOT / "data"


def load_config(path: Path = CONFIG) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def prior_row_counts(audit_dir: Path) -> dict[str, int]:
    prev = load_previous_run(audit_dir)
    if not prev:
        return {}
    return {e["dataset_key"]: e["row_count"] for e in prev.get("extracts", [])}


def cmd_run(args: argparse.Namespace) -> int:
    cfg = load_config()
    source = cfg["source"]
    specs = cfg["datasets"]

    if args.only:
        wanted = {k.strip() for k in args.only.split(",")}
        specs = [s for s in specs if s["key"] in wanted]
        if not specs:
            print(f"No datasets matched --only {args.only}", file=sys.stderr)
            return 2

    audit_dir = DATA / "audit"
    manifest = RunManifest()
    validator = Validator(cfg.get("validation", {}))
    catalog = CatalogClient(
        timeout=source.get("timeout_seconds", 120),
        max_retries=source.get("max_retries", 5),
    )
    extractor = Extractor(
        raw_dir=DATA / "raw",
        page_size=source.get("page_size", 2000),
        max_retries=source.get("max_retries", 5),
        timeout=source.get("timeout_seconds", 120),
    )
    warehouse = Warehouse(DATA / "warehouse" / "cms.duckdb")
    baseline = prior_row_counts(audit_dir)

    print(f"run_id {manifest.run_id}")
    print(f"resolving {len(specs)} datasets against the CMS catalog\n")

    facilities, measures = [], []
    spec_index = {s["key"]: s for s in specs}

    for spec in specs:
        key = spec["key"]
        try:
            entry = catalog.resolve(spec["dataset_id"])
            df, record = extractor.fetch(spec, entry)
            df = normalize_columns(df)

            results = validator.run(spec, df, record, baseline.get(key))
            manifest.validations.extend(results)
            manifest.extracts.append(record)

            blocking = [r for r in results if r.severity == "fail" and not r.passed]
            if blocking:
                print(f"  [BLOCK] {key:24s} {record.row_count:>8,} rows  "
                      f"{len(blocking)} blocking control(s) failed")
                for b in blocking:
                    print(f"          - {b.check}: {b.detail}")
                continue  # do not promote failing data into the warehouse

            warehouse.load_raw(key, df)
            if spec["grain"] == "facility":
                facilities.append(to_facility_dim(df, spec))
            else:
                measures.append(to_measure_fact(df, spec))

            warns = sum(1 for r in results if r.severity == "warn" and not r.passed)
            flag = f"{warns} advisory" if warns else "clean"
            print(f"  [ok]    {key:24s} {record.row_count:>8,} rows  "
                  f"{record.column_count:>3} cols  {flag}")

        except Exception as exc:  # noqa: BLE001 - recorded, run continues
            print(f"  [ERROR] {key:24s} {exc}", file=sys.stderr)
            if args.verbose:
                traceback.print_exc()
            manifest.extracts.append(ExtractRecord(
                dataset_key=key, dataset_id=spec["dataset_id"], title=spec["title"],
                distribution_id=None, source_url="", cms_modified=None,
                cms_released=None, cms_next_update=None, row_count=0, column_count=0,
                content_sha256="", extracted_at=utcnow(), duration_seconds=0.0,
                status="error", error=str(exc)[:500],
            ))

    counts = warehouse.load_conformed(facilities, measures)
    manifest.close()
    manifest.write(audit_dir)

    scores = build(manifest, spec_index)
    roll = portfolio_score(scores)
    (audit_dir / "scorecard.json").write_text(
        json.dumps({"portfolio": roll, "datasets": as_dicts(scores)}, indent=2),
        encoding="utf-8",
    )

    print("\nwarehouse")
    for table, n in sorted(warehouse.table_sizes().items()):
        print(f"  {table:28s} {n:>9,}")
    warehouse.close()

    print(f"\nportfolio score {roll['score']} ({roll['grade']})  "
          f"{roll['checks_run']} controls  "
          f"{roll['blocking_failures']} blocking  "
          f"{roll['advisory_failures']} advisory")

    from .report import render  # local import keeps `catalog` fast
    out = render(DATA / "audit", DATA / "reports")
    print(f"report {out}")

    return manifest.exit_code()


def cmd_catalog(args: argparse.Namespace) -> int:
    client = CatalogClient()
    entries = client.search(args.search) if args.search else list(client.load().values())
    print(f"{len(entries)} dataset(s)\n")
    for e in sorted(entries, key=lambda x: x.title)[: args.limit]:
        print(f"{e.dataset_id:12s} {e.modified or '?':12s} {e.title[:70]}")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    from .report import render
    print(render(DATA / "audit", DATA / "reports"))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cms-compliance-pipeline")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="extract, validate, load, report")
    run.add_argument("--only", help="comma-separated dataset keys")
    run.add_argument("--verbose", action="store_true")
    run.set_defaults(func=cmd_run)

    cat = sub.add_parser("catalog", help="browse the CMS catalog")
    cat.add_argument("--search", help="filter titles")
    cat.add_argument("--limit", type=int, default=50)
    cat.set_defaults(func=cmd_catalog)

    rep = sub.add_parser("report", help="rebuild the HTML report")
    rep.set_defaults(func=cmd_report)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
