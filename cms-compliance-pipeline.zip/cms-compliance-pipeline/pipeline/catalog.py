"""
CMS Provider Data Catalog client.

CMS re-issues distribution IDs whenever a dataset is republished, so hardcoding
them silently breaks pipelines. This module resolves the stable dataset_id to
the *current* distribution at runtime and surfaces the publication metadata
(modified / released / nextUpdateDate) used by the staleness gate.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import requests

METASTORE = "https://data.cms.gov/provider-data/api/1/metastore/schemas/dataset/items"
USER_AGENT = "cms-compliance-pipeline/1.0 (portfolio; public-use data only)"


@dataclass
class CatalogEntry:
    dataset_id: str
    title: str
    distribution_id: str | None
    modified: str | None
    released: str | None
    next_update: str | None
    description: str | None
    download_url: str | None


class CatalogClient:
    def __init__(self, timeout: int = 120, max_retries: int = 5):
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})
        self._cache: dict[str, CatalogEntry] | None = None

    def _get(self, url: str, params: dict | None = None) -> dict | list:
        last: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                resp = self.session.get(url, params=params, timeout=self.timeout)
                if resp.status_code in (429, 500, 502, 503, 504):
                    raise requests.HTTPError(f"retryable status {resp.status_code}")
                if 400 <= resp.status_code < 500:
                    raise RuntimeError(f"HTTP {resp.status_code} from CMS metastore")
                resp.raise_for_status()
                return resp.json()
            except RuntimeError:
                raise
            except Exception as exc:  # noqa: BLE001 - retried below
                last = exc
                time.sleep(min(2**attempt, 30))
        raise RuntimeError(f"GET failed after {self.max_retries} attempts: {url}") from last

    def load(self, force: bool = False) -> dict[str, CatalogEntry]:
        """Fetch and index the full catalog by dataset identifier."""
        if self._cache is not None and not force:
            return self._cache

        raw = self._get(METASTORE, params={"show-reference-ids": "true"})
        index: dict[str, CatalogEntry] = {}

        for item in raw:
            dists = item.get("distribution") or []
            dist_id, download = None, None
            for d in dists:
                if d.get("identifier"):
                    dist_id = d["identifier"]
                    download = d.get("data", {}).get("downloadURL") or d.get("downloadURL")
                    break
            index[item.get("identifier")] = CatalogEntry(
                dataset_id=item.get("identifier"),
                title=item.get("title", ""),
                distribution_id=dist_id,
                modified=item.get("modified"),
                released=item.get("released"),
                next_update=item.get("nextUpdateDate"),
                description=(item.get("description") or "")[:500] or None,
                download_url=download,
            )

        self._cache = index
        return index

    def resolve(self, dataset_id: str) -> CatalogEntry:
        entry = self.load().get(dataset_id)
        if entry is None:
            raise KeyError(
                f"dataset_id {dataset_id!r} not present in the CMS catalog — "
                "it may have been retired or renamed upstream."
            )
        if not entry.distribution_id:
            raise ValueError(f"dataset {dataset_id!r} has no queryable distribution")
        return entry

    def search(self, term: str) -> list[CatalogEntry]:
        term = term.lower()
        return [e for e in self.load().values() if term in e.title.lower()]
