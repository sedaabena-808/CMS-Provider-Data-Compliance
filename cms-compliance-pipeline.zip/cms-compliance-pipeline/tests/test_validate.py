"""
Control-engine tests.

These exercise the validation layer against synthetic frames rather than the
live CMS API, so CI stays deterministic and offline. The API-facing code is
covered separately by the scheduled pipeline run itself.
"""

from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import pytest

from pipeline.audit import ExtractRecord, RunManifest, sha256_records, utcnow
from pipeline.scorecard import build, grade, portfolio_score
from pipeline.validate import Validator
from pipeline.warehouse import normalize_columns, to_facility_dim, to_measure_fact

RULES = {"row_count_drift_pct": 20, "null_rate_threshold": 0.6}

SPEC = {
    "key": "demo",
    "dataset_id": "aaaa-bbbb",
    "title": "Demo Dataset",
    "domain": "quality",
    "grain": "facility_measure",
    "criticality": "high",
    "expected_cadence_days": 120,
    "primary_key": ["facility_id", "measure_id"],
    "required_columns": ["facility_id", "measure_id", "score"],
}


def make_record(**overrides) -> ExtractRecord:
    base = dict(
        dataset_key="demo", dataset_id="aaaa-bbbb", title="Demo Dataset",
        distribution_id="dist-1", source_url="https://example.test",
        cms_modified=date.today().isoformat(), cms_released=None,
        cms_next_update=(date.today() + timedelta(days=30)).isoformat(),
        row_count=3, column_count=3, content_sha256="x",
        extracted_at=utcnow(), duration_seconds=0.1,
    )
    base.update(overrides)
    return ExtractRecord(**base)


def good_frame() -> pd.DataFrame:
    return pd.DataFrame({
        "facility_id": ["010001", "010001", "020002"],
        "measure_id": ["OP_18b", "OP_22", "OP_18b"],
        "score": ["142", "2", "Not Available"],
    })


def results_by_prefix(results, prefix):
    return [r for r in results if r.check.startswith(prefix)]


# -- schema and key controls ------------------------------------------

def test_clean_frame_has_no_blocking_failures():
    out = Validator(RULES).run(SPEC, good_frame(), make_record())
    assert [r for r in out if r.severity == "fail" and not r.passed] == []


def test_missing_required_column_blocks():
    df = good_frame().drop(columns=["score"])
    out = Validator(RULES).run(SPEC, df, make_record(column_count=2))
    schema = results_by_prefix(out, "SCHEMA-01")[0]
    assert schema.severity == "fail" and not schema.passed
    assert "score" in schema.detail


def test_duplicate_primary_key_raises_advisory_not_blocking():
    df = pd.concat([good_frame(), good_frame().head(1)], ignore_index=True)
    out = Validator(RULES).run(SPEC, df, make_record(row_count=4))
    dup = results_by_prefix(out, "KEY-02")[0]
    assert dup.severity == "warn" and not dup.passed and dup.observed == 1


def test_low_criticality_downgrades_blocking_to_advisory():
    spec = {**SPEC, "criticality": "low"}
    df = good_frame().drop(columns=["measure_id"])
    out = Validator(RULES).run(spec, df, make_record())
    assert all(r.severity != "fail" for r in out)


# -- identifier screening ---------------------------------------------

@pytest.mark.parametrize("col", ["ssn", "patient_name", "date_of_birth", "member_id", "mrn"])
def test_phi_screen_blocks_direct_identifiers(col):
    df = good_frame().assign(**{col: ["a", "b", "c"]})
    out = Validator(RULES).run(SPEC, df, make_record())
    phi = results_by_prefix(out, "PHI-01")[0]
    assert phi.severity == "fail" and not phi.passed


def test_phi_screen_passes_on_public_use_schema():
    out = Validator(RULES).run(SPEC, good_frame(), make_record())
    assert results_by_prefix(out, "PHI-01")[0].passed


# -- freshness and volume ---------------------------------------------

def test_stale_upstream_file_flagged():
    stale = (date.today() - timedelta(days=400)).isoformat()
    out = Validator(RULES).run(SPEC, good_frame(), make_record(cms_modified=stale))
    fresh = results_by_prefix(out, "FRESH-01")[0]
    assert not fresh.passed and fresh.observed >= 400


def test_overdue_next_update_flagged():
    overdue = (date.today() - timedelta(days=10)).isoformat()
    out = Validator(RULES).run(SPEC, good_frame(), make_record(cms_next_update=overdue))
    assert not results_by_prefix(out, "FRESH-02")[0].passed


def test_row_count_drift_within_tolerance_passes():
    out = Validator(RULES).run(SPEC, good_frame(), make_record(row_count=105), prior_rows=100)
    assert results_by_prefix(out, "VOL-01")[0].passed


def test_row_count_collapse_flagged():
    out = Validator(RULES).run(SPEC, good_frame(), make_record(row_count=40), prior_rows=100)
    vol = results_by_prefix(out, "VOL-01")[0]
    assert not vol.passed and vol.observed == 60.0


def test_first_run_establishes_baseline_without_failing():
    out = Validator(RULES).run(SPEC, good_frame(), make_record(), prior_rows=None)
    assert results_by_prefix(out, "VOL-01")[0].passed


# -- typing and nulls --------------------------------------------------

def test_categorical_measure_exempt_from_numeric_parse():
    spec = {**SPEC, "numeric_measure": False}
    df = good_frame().assign(score=["Yes", "No", "Not Available"])
    out = Validator(RULES).run(spec, df, make_record())
    assert results_by_prefix(out, "TYPE-01")[0].passed


def test_fully_suppressed_numeric_column_flagged():
    df = good_frame().assign(score=["Not Available"] * 3)
    out = Validator(RULES).run(SPEC, df, make_record())
    assert not results_by_prefix(out, "TYPE-01")[0].passed


def test_high_null_rate_flagged():
    df = good_frame().assign(score=["", "", ""])
    out = Validator(RULES).run(SPEC, df, make_record())
    nulls = [r for r in out if r.check.startswith("NULL-01 null_rate[score]")][0]
    assert not nulls.passed and nulls.observed == 1.0


# -- transform ---------------------------------------------------------

def test_normalize_columns_snake_cases_cms_headers():
    df = pd.DataFrame(columns=["Facility ID", "Measure Name (2024)", "Score%"])
    assert list(normalize_columns(df).columns) == [
        "facility_id", "measure_name_2024", "score",
    ]


def test_measure_fact_marks_suppressed_rows():
    fact = to_measure_fact(good_frame(), SPEC)
    assert len(fact) == 3
    assert fact["is_suppressed"].sum() == 1
    assert fact["score_numeric"].max() == 142


def test_facility_dim_dedupes_and_drops_blank_ids():
    df = pd.DataFrame({
        "facility_id": ["010001", "", "020002"],
        "facility_name": ["A", "B", "C"],
        "state": ["AL", "AL", "AK"],
    })
    dim = to_facility_dim(df, {**SPEC, "grain": "facility"})
    assert len(dim) == 2
    assert "" not in set(dim["facility_id"])


# -- scoring and audit -------------------------------------------------

def test_blocking_failure_forces_nonzero_exit_code():
    manifest = RunManifest()
    df = good_frame().drop(columns=["score"])
    manifest.extracts.append(make_record())
    manifest.validations.extend(Validator(RULES).run(SPEC, df, make_record()))
    assert manifest.exit_code() == 1


def test_clean_run_exits_zero():
    manifest = RunManifest()
    manifest.extracts.append(make_record())
    manifest.validations.extend(Validator(RULES).run(SPEC, good_frame(), make_record()))
    assert manifest.exit_code() == 0


def test_scorecard_deducts_for_exceptions():
    manifest = RunManifest()
    manifest.extracts.append(make_record())
    manifest.validations.extend(
        Validator(RULES).run(SPEC, good_frame(), make_record(row_count=40), prior_rows=100)
    )
    scores = build(manifest, {"demo": SPEC})
    assert scores[0].score < 100
    assert portfolio_score(scores)["datasets"] == 1


def test_criticality_weighting_favours_high_criticality_datasets():
    manifest = RunManifest()
    manifest.extracts.append(make_record())
    scores = build(manifest, {"demo": SPEC})
    assert portfolio_score(scores)["score"] == scores[0].score


@pytest.mark.parametrize("value,expected", [(95, "A"), (85, "B"), (75, "C"), (65, "D"), (10, "F")])
def test_grade_bands(value, expected):
    assert grade(value) == expected


def test_content_hash_is_order_independent():
    a = [{"x": 1, "y": 2}]
    b = [{"y": 2, "x": 1}]
    assert sha256_records(a) == sha256_records(b)


def test_content_hash_changes_with_data():
    assert sha256_records([{"x": 1}]) != sha256_records([{"x": 2}])
